//book constructor
function Book(title, author, isbn) {
    this.title = title;
    this.author = author;
    this.isbn = isbn;
}

//UI constructor
function UI() {}

//ui functions
//function for adding a book
UI.prototype.addBookToList = function(book) {
    //locate book-list and define it
    const bookList = document.querySelector('#book-list');

    //create a <tr></tr> and define it as row
    const row = document.createElement('tr');

    //add content for row
    row.innerHTML = `
        <td>${book.title}</td>
        <td>${book.author}</td>
        <td>${book.isbn}</td>
        <td><a href='#' class='delete'>X</a><td>
    `
    //the book instance is passed in to this function, book.title, book.author and book.isbn access the values in this instance
    //add a class name for X for deleting it in the future

    //put row inside the book list
    bookList.appendChild(row);
}

//function for clearing the fields
UI.prototype.clearFields = function() {
    document.querySelector('#title').value = '';
    document.querySelector('#author').value = '';
    document.querySelector('#isbn').value = '';
}

//function for deleting a book
UI.prototype.deleteBook = function(target) {
    //the target parameter here is e.target, check how the function is called below
    if(target.className = 'delete') {
        target.parentElement.parentElement.remove();
    }  
}

//function for alert messages
UI.prototype.showAlert = function(message, nameOfClass) {
    //create a div with a specific class name and message
    //create div tag
    const div = document.createElement('div');

    //give div class name
    div.className = nameOfClass;

    //createa a message
    const msg = document.createTextNode(message);

    //append message in div
    div.appendChild(msg);
    
    //insert the div before form using parentDiv.insertBefore(newNode, referenceNode)
    //find parentDiv and referenceNode
    const container = document.querySelector('.container'),
          form = document.querySelector('#book-form');
    
    //insert div before form using the parentDiv
    container.insertBefore(div, form);

    //set it to disappear in 2 seconds
    setTimeout(function(){
        div.remove();
    }, 2000);
}

//event listener for adding a book
document.querySelector('#book-form').addEventListener('submit', function(e) {

    //define values
    const title = document.querySelector('#title').value,
          author = document.querySelector('#author').value,
          isbn = document.querySelector('#isbn').value;

    //instantiate a book
    const book = new Book(title, author, isbn);//Book {title: 'a', author: 'vea', isbn: 'e'}

    //instantiate ui 
    const ui = new UI();

    //validate first for next action
    if (title === '' || author === '' || isbn === '') {
        //if one of the fields is empty, run ui function showAlert(message, nameOfClass) with values attached
        
        //show error function
        ui.showAlert('Please fill in the fields', 'alert error');
    } else {
        //if all the fields are filled, run ui functions

        //ui add a book function for adding a book
        ui.addBookToList(book);

        //show success function
        ui.showAlert('Book is added successfully', 'alert success');

        //ui clear fields function
        ui.clearFields();
    }

    //prevent default
    e.preventDefault();
})

//event listener for deleting a book
document.querySelector('#book-list').addEventListener('click', function(e){

    //instantiate ui
    const ui = new UI();

    //ui delete a book function
    ui.deleteBook(e.target);//since e is already passed in in the future, the value that is passed in the delete a book function should be e.target

    //show sucess function for deleting a book
    ui.showAlert('Book is deleted', 'alert success');

    //prevent default
    e.preventDefault();
})

