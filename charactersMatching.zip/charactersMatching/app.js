

//define UI variables
const wordInput = document.querySelector('#word-input');
      message = document.querySelector('#message');
      addBtn = document.querySelector('.green');
      form = document.querySelector('#word-form');

      inputField = document.querySelector('.input-field');
      filterInput = document.querySelector('#filter');
      clearBtn = document.querySelector('.cyan');
      collection = document.querySelector('.ul');
    
//adding words
form.addEventListener('submit', addWords);

//addWords function
function addWords(e) {
    //response when word input is empty
    if(wordInput.value === '') {
        alert('Please add your word')
    //response when word input is not empty
    } else {
        //create new li item with a class name 'collection-item' and content of the word input value
        const newList = document.createElement('li');
        newList.className = 'collection-item';
        newList.appendChild(document.createTextNode(wordInput.value));
        
        //create an a tag with a class name 'delete-item secondary-content' and content '<i class="fa fa-remove"></i>'
        const newLink = document.createElement('a');
        newLink.className = 'delete-item secondary-content';
        newLink.innerHTML = '<i class="fa fa-remove"></i>';
        newList.appendChild(newLink);

        //put the new li newList into the ul collection and add a class name collection
        collection.appendChild(newList);
        collection.classList.add('collection');

        //clear the input
        wordInput.value = '';
    };

    //prevent default
    e.preventDefault();
};

//clearing words
clearBtn.addEventListener('click', clearWords);
collection.addEventListener('mousedown', cancelItem);

//clearWords function
function clearWords() {
    //clear the ul collection list and remove the class name collection
    collection.textContent = '';
    collection.classList.remove('collection');
};

//cancelItem function
function cancelItem(e) {
    if(e.target.parentElement.classList.contains('delete-item')) {
        e.target.parentElement.parentElement.remove();

        if(collection.children.length === 0) {
            collection.classList.remove('collection');
        }
    } 
};

//filter words
filterInput.addEventListener('keyup', filterWords);

//filterWords function
function filterWords(e) {
   //document each typed text and turn it into lower case
   const text = e.target.value.toLowerCase();
   
   //define all li tag items as words
   const words = document.querySelectorAll('.collection-item');

   //loop through each li tag item

   //grab the text node which is the firstChild, extract the list text using .textContent, turn it into lower case
   //check if the list text contains any of the text
   //The indexOf() method returns the position of the first occurrence of a value in a string. The indexOf() method returns -1 if the value is not found.
   words.forEach(function(word){
    const listText = word.firstChild.textContent
    if(listText.toLowerCase().indexOf(text) !== -1) {
        word.style.display = 'block';
    } else {
        word.style.display = 'none';
    }
   });

};







