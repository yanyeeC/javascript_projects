/*
The formula for calculating your monthly payment is:
A = P (r (1+r)^n) / ( (1+r)^n -1 )

A = Payment amount per period
P = Initial principal or loan amount 
r = Interest rate per period 
n = Total number of payments or periods

When you plug in your numbers, it would shake out as this:
P = $10,000
r = 7.5% per year / 100 / 12 months = 0.00625 (0.625% per period)
n = 5 years x 12 months = 60 total periods
*/

//define UI variables
const form = document.querySelector('#loan-form');
const amount = document.querySelector('#amount');
const interest = document.querySelector('#interest');
const years = document.querySelector('#years');
const monthlyPayment = document.querySelector('#monthly-payment');
const totalPayment = document.querySelector('#total-payment');
const totalInterest = document.querySelector('#total-interest');
const loader = document.querySelector('#loading');
const results = document.querySelector('#results');
const newDiv = document.querySelector('#error-message');

//hide loader
loader.style.display = 'none';

//hide results
results.style.display = 'none';

//add event
form.addEventListener('submit', function(e) {
    if(amount.value === '' || interest.value === '' || years.value === '') {
        //show error message
        showError();
        
        //clear error message
        setTimeout(clearError, 2000);

    } else {
        //show loader
        loader.style.display = 'block';

        //set time for results to be calculated
        setTimeout(loadResults, 1000);

        //change submit button
        document.querySelector('.btn-dark').value = 'Reset';
        document.querySelector('.btn-dark').classList.add('reset');

        //add a reload event
        form.addEventListener('mousedown', reloadPage);
    };

    //prevent default
    e.preventDefault();
});


//add results function
function loadResults() {
        //calculating answer
        //months to pay
        const monthsToPay = parseFloat(years.value) * 12;

        //interest per month
        const interestPerMonth = parseFloat(interest.value) / 100 / 12;

        //principal
        const principal = parseFloat(amount.value);

        //combined equation
        const x = Math.pow(1 + interestPerMonth, monthsToPay);

        //monthly payment 
        const monthly = (principal * interestPerMonth * x) / (x - 1);

        //generating answers
        //monthly payment answer
        monthlyPayment.value = monthly.toFixed(2);

        //total payment answer
        totalPayment.value = (monthly * monthsToPay).toFixed(2);

        //total interest answer
        totalInterest.value = ((monthly * monthsToPay) - principal).toFixed(2);

        //display results
        //hide loader
        loader.style.display = 'none';

        //show results
        results.style.display = 'block';

};



//show error function
function showError() {
    newDiv.setAttribute('class', 'red');
    newDiv.textContent = 'Please check your input';
};

//reload function
function reloadPage(e) {
    if (e.target.classList.contains('reset')) {
        window.location.reload();
    };    
};

//clear error function
function clearError() {
    newDiv.style.display = 'none';
};













