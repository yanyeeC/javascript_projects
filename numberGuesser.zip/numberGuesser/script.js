//set values
let min = 0;
    max = 100;
    winningNum = 56; //randomNum();


    /*
    function randomNum() {
        return Math.floor(Math.random() * 100);
    };
    */

//define UI variables
const guessInput = document.querySelector('#guess-input');
      submitBtn = document.querySelector('#guess-btn');
      message = document.querySelector('#message');
      minNum = document.querySelector('#min');
      maxNum = document.querySelector('#max');
      game = document.querySelector('#game');
      
//add an event listener for submit
submitBtn.addEventListener('click', loadResult);

//add an event listener for reload
game.addEventListener('mousedown', reloadPage);

//store guessed numbers
//let guessed_numbers = [];

//submit event function
function loadResult() {
    const guessNum = parseInt(guessInput.value)//use parseInt() to make sure the value is always a number and no input = NaN

    //step 1: when input is invalid
    if(isNaN(guessNum) || guessNum < min || guessNum > max) {
        loadWarning(`Choose a number between ${min} and ${max}`, 'red') //load a warning
    
    //step 2: when win 
    } else if(guessNum === winningNum) {
        loadMessage(true, `${guessNum} is correct!`)//load a message

    //step 3: when lose
    } else if (guessNum < winningNum) {  
        min = guessNum;
        minNum.textContent = min;
        gameLost(`Incorrect, this number is between ${min} and ${max}`, 'purple')//load losing message
        
    } else if (guessNum > winningNum) {
        max = guessNum;
        maxNum.textContent = max;
        gameLost(`Incorrect, this number is between ${min} and ${max}`, 'purple')//load losing message
    }
};

    //when input is invalid
    //warning function
    function loadWarning(msg, col) {
        message.textContent = msg;
        message.style.color = col;
    }

    //when lose
    function gameLost(msg, col) {
        message.textContent = msg;
        message.style.color = col;
    }

    //when win and game over
    function loadMessage(won, msg) {
        let col;
        won === true ? col = 'green': col = 'purple';
        message.textContent = msg;
        message.style.color = col;

        guessInput.disabled = true;
        submitBtn.value = 'play again';
        submitBtn.classList.add('play-again');
    }

    //reload function
    function reloadPage(e) {
        if(e.target.classList.contains('play-again')) {
            window.location.reload();
        }
    }





    


    










